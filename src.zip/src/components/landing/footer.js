import React from 'react'
import linkedin from '../../assets/linkedin.png';

export default function Footer() {
  return (
    <div class="flex flex-col justify-between mx-10">
    <footer class="h-10">Copyright © 2022 PiggyBanc Association</footer>
  </div>
  
     )
}